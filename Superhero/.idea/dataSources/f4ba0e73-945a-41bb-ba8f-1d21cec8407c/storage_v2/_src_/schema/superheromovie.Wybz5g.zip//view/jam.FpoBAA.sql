create definer = root@localhost view jam as
select `superheromovie`.`movie`.`movie_name`           AS `movie_name`,
       `superheromovie`.`movie`.`main_lead`            AS `main_lead`,
       `superheromovie`.`movie`.`director`             AS `director`,
       `superheromovie`.`movie`.`budget`               AS `budget`,
       `superheromovie`.`movie`.`domestic_box_office`  AS `domestic_box_office`,
       `superheromovie`.`movie`.`oversea_box_office`   AS `oversea_box_office`,
       `superheromovie`.`movie`.`worldwide_box_office` AS `worldwide_box_office`,
       `superheromovie`.`movie`.`description`          AS `description`,
       `superheromovie`.`movie`.`ranking`              AS `ranking`,
       `superheromovie`.`movie`.`Title`                AS `Title`,
       `superheromovie`.`movie`.`oname`                AS `oname`
from `superheromovie`.`movie`
where (`superheromovie`.`movie`.`Title` = 'IRON MAN');

